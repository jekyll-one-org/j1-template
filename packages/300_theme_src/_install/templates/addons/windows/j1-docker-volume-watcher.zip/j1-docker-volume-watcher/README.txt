C:\j1-docker-volume-watcher>set | findstr DOCKER
--
DOCKER_CERT_PATH=C:\Users\jadams\.docker\machine\machines\default
DOCKER_HOST=tcp://192.168.99.100:2376
DOCKER_MACHINE_NAME=default
DOCKER_TLS_VERIFY=1
DOCKER_TOOLBOX_INSTALL_PATH=C:\Program Files\Docker Toolbox

